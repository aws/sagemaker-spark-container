# This file will end up being largely rewritten -- ignoring flake8
# flake8: noqa
import json
import logging
import os
import pathlib
import socket
import subprocess
from distutils import dir_util
from glob import glob
from shutil import copyfile
from typing import Any, Dict, List, Mapping, Sequence, Union

import psutil
from smspark.config import Configuration

HADOOP_CONFIG_PATH = "/opt/hadoop-config/"
HADOOP_PATH = "/usr/lib/hadoop"
SPARK_PATH = "/usr/lib/spark"
HIVE_PATH = "/usr/lib/hive"
PROCESSING_CONF_INPUT_PATH = "/opt/ml/processing/input/conf/configuration.json"
EMR_CONFIGURE_APPS_URL = "https://docs.aws.amazon.com/emr/latest/ReleaseGuide/emr-configure-apps.html"

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def deserialize_user_configuration(configuration_dict_or_list) -> Union[List[Configuration], Configuration]:
    if isinstance(configuration_dict_or_list, dict):
        return deserialize_user_configuration_dict(configuration_dict_or_list)
    elif isinstance(configuration_dict_or_list, list):
        list_of_configurations = []
        for conf in configuration_dict_or_list:
            configuration = deserialize_user_configuration_dict(conf)
            list_of_configurations.append(configuration)
        return list_of_configurations


def deserialize_user_configuration_dict(configuration_dict: dict) -> Configuration:
    if configuration_dict.get("Configurations"):
        configurations_inner = configuration_dict["Configurations"] if configuration_dict["Configurations"] else ()
        return Configuration(
            Classification=configuration_dict["Classification"],
            Properties=configuration_dict["Properties"],
            Configurations=deserialize_user_configuration(configurations_inner),
        )
    else:
        return Configuration(
            Classification=configuration_dict["Classification"], Properties=configuration_dict["Properties"]
        )


def write_user_configuration() -> None:
    path = pathlib.Path(PROCESSING_CONF_INPUT_PATH)

    def _write_conf(conf: Configuration) -> None:
        logging.info("Writing user config to {}".format(conf.path))
        conf_string = conf.write_config()
        logging.info("Configuration at {} is: \n{}".format(conf.path, conf_string))

    if path.exists():
        logging.info("reading user configuration from {}".format(str(path)))
        with open(str(path), "r") as config:
            user_configuration_list_or_dict = json.load(config)
            logging.info(
                "User configuration list or dict: {} , type {}".format(
                    user_configuration_list_or_dict, type(user_configuration_list_or_dict),
                )
            )
            user_confs = deserialize_user_configuration(user_configuration_list_or_dict)
            if isinstance(user_confs, Configuration):
                _write_conf(user_confs)
            elif isinstance(user_confs, list):
                for user_conf in user_confs:
                    _write_conf(user_conf)
            else:
                # FIXME: customer error
                raise ValueError(
                    "Could not determine type of user configuration {}. Please consult {} for more information.".format(
                        user_configuration_list_or_dict, EMR_CONFIGURE_APPS_URL
                    )
                )
    else:
        logging.info("No file at {} exists, skipping user configuration".format(str(path)))


def copy_cluster_config() -> None:
    src = os.path.join(HADOOP_CONFIG_PATH, "hdfs-site.xml")
    dst = HADOOP_PATH + "/etc/hadoop/hdfs-site.xml"
    logging.info("copying {} to {}".format(src, dst))
    copyfile(src, dst)

    src = os.path.join(HADOOP_CONFIG_PATH, "core-site.xml")
    dst = HADOOP_PATH + "/etc/hadoop/core-site.xml"
    logging.info("copying {} to {}".format(src, dst))
    copyfile(src, dst)

    src = os.path.join(HADOOP_CONFIG_PATH, "yarn-site.xml")
    dst = HADOOP_PATH + "/etc/hadoop/yarn-site.xml"
    logging.info("copying {} to {}".format(src, dst))
    copyfile(src, dst)

    src = os.path.join(HADOOP_CONFIG_PATH, "spark-defaults.conf")
    dst = SPARK_PATH + "/conf/spark-defaults.conf"
    logging.info("copying {} to {}".format(src, dst))
    copyfile(src, dst)

    # copy container's own spark-env.sh to conf dir, otherwise some env
    # vars will be overwritten
    src = os.path.join(HADOOP_CONFIG_PATH, "spark-env.sh")
    dst = SPARK_PATH + "/conf/spark-env.sh"
    copyfile(src, dst)

    src = os.path.join(PROCESSING_CONF_INPUT_PATH, "hive-site.xml")
    dst = SPARK_PATH + "/conf/hive-site.xml"
    if os.path.isfile(src):
        try:
            logging.info("copying {} to {}".format(src, dst))
            copyfile(src, dst)
        except:
            pass


def copy_aws_jars() -> None:
    jar_dest = SPARK_PATH + "/jars"
    for f in glob("/usr/share/aws/aws-java-sdk/*.jar"):
        copyfile(f, os.path.join(jar_dest, os.path.basename(f)))
    hadoop_aws_jar = "hadoop-aws-2.8.5-amzn-5.jar"
    jets3t_jar = "jets3t-0.9.0.jar"
    copyfile(
        os.path.join(HADOOP_PATH, hadoop_aws_jar), os.path.join(jar_dest, hadoop_aws_jar),
    )
    # this jar required for using s3a client
    copyfile(
        os.path.join(HADOOP_PATH + "/lib", jets3t_jar), os.path.join(jar_dest, jets3t_jar),
    )
    # copy hmclient (glue data catalog hive metastore client) jars to classpath:
    # https://github.com/awslabs/aws-glue-data-catalog-client-for-apache-hive-metastore
    # TODO (amoeller): don't copy to spark home, add to spark driver/executor classpath instead
    # TODO (amoeller): figure out what EMR deps to include in container and what not to.
    for f in glob("/usr/share/aws/hmclient/lib/*.jar"):
        copyfile(f, os.path.join(jar_dest, os.path.basename(f)))


def write_runtime_cluster_config() -> None:
    resource_config = get_resource_config()
    primary_host = resource_config["hosts"][0]
    primary_ip = socket.gethostbyname(primary_host)
    current_host = resource_config["current_host"]

    core_site_file_path = HADOOP_PATH + "/etc/hadoop/core-site.xml"
    yarn_site_file_path = HADOOP_PATH + "/etc/hadoop/yarn-site.xml"

    hadoop_env_file_path = HADOOP_PATH + "/etc/hadoop/hadoop-env.sh"
    yarn_env_file_path = HADOOP_PATH + "/etc/hadoop/yarn-env.sh"
    spark_conf_file_path = SPARK_PATH + "/conf/spark-defaults.conf"

    # Pass through environment variables to hadoop env
    with open(hadoop_env_file_path, "a") as hadoop_env_file:
        hadoop_env_file.write("export SPARK_MASTER_HOST=" + primary_ip + "\n")
        hadoop_env_file.write(
            "export AWS_CONTAINER_CREDENTIALS_RELATIVE_URI="
            + os.environ.get("AWS_CONTAINER_CREDENTIALS_RELATIVE_URI", "")
            + "\n"
        )

    # Add YARN log directory
    with open(yarn_env_file_path, "a") as yarn_env_file:
        yarn_env_file.write("export YARN_LOG_DIR=/var/log/yarn/")

    # Configure ip address for name node
    with open(core_site_file_path, "r") as core_file:
        file_data = core_file.read()
    file_data = file_data.replace("nn_uri", primary_ip)
    with open(core_site_file_path, "w") as core_file:
        core_file.write(file_data)

    # Configure hostname for resource manager and node manager
    with open(yarn_site_file_path, "r") as yarn_file:
        file_data = yarn_file.read()
    file_data = file_data.replace("rm_hostname", primary_ip)
    file_data = file_data.replace("nm_hostname", current_host)
    with open(yarn_site_file_path, "w") as yarn_file:
        yarn_file.write(file_data)

    # Configure yarn resource limitation
    mem = int(psutil.virtual_memory().total / (1024 * 1024))  # total physical memory in mb
    cores = psutil.cpu_count(logical=True)  # vCPUs

    minimum_allocation_mb = "1"
    maximum_allocation_mb = str(mem)
    minimum_allocation_vcores = "1"
    maximum_allocation_vcores = str(cores)
    # Add some residual in memory due to rounding in memory allocation
    memory_mb_total = str(mem + 2048)
    # Ensure core allocations
    cpu_vcores_total = str(cores * 16)

    with open(yarn_site_file_path, "r") as yarn_file:
        file_data = yarn_file.read()
    file_data = file_data.replace("minimum_allocation_mb", minimum_allocation_mb)
    file_data = file_data.replace("maximum_allocation_mb", maximum_allocation_mb)
    file_data = file_data.replace("minimum_allocation_vcores", minimum_allocation_vcores)
    file_data = file_data.replace("maximum_allocation_vcores", maximum_allocation_vcores)
    file_data = file_data.replace("memory_mb_total", memory_mb_total)
    file_data = file_data.replace("cpu_vcores_total", cpu_vcores_total)
    with open(yarn_site_file_path, "w") as yarn_file:
        yarn_file.write(file_data)

    # Configure Spark defaults
    with open(spark_conf_file_path, "r") as spark_file:
        file_data = spark_file.read()
    file_data = file_data.replace("sd_host", primary_ip)
    file_data = file_data.replace("exec_mem", str(int((mem / 3) * 2.2)) + "m")
    file_data = file_data.replace("exec_cores", str(min(5, cores - 1)))
    with open(spark_conf_file_path, "w") as spark_file:
        spark_file.write(file_data)
    print("Finished Yarn configuration files setup.\n")


def get_resource_config() -> Dict[str, Any]:
    with open("/opt/ml/config/resourceconfig.json") as resource_config_file:
        return json.load(resource_config_file)


def start_daemons() -> None:
    resource_config = get_resource_config()
    current_host = resource_config["current_host"]
    primary_host = resource_config["hosts"][0]

    # TODO: sync with EMR puppet scripts - ensure we are following best practices for starting hdfs/yarn daemons
    cmd_prep_namenode_dir = "rm -rf /opt/amazon/hadoop/hdfs/namenode && mkdir -p /opt/amazon/hadoop/hdfs/namenode"
    cmd_prep_datanode_dir = "rm -rf /opt/amazon/hadoop/hdfs/datanode && mkdir -p /opt/amazon/hadoop/hdfs/datanode"
    cmd_namenode_format = "hdfs namenode -format -force"
    cmd_namenode_start = "hdfs namenode"
    cmd_datanode_start = "hdfs datanode"
    cmd_resourcemanager_start = "yarn resourcemanager"
    cmd_nodemanager_start = "yarn nodemanager"

    if current_host == primary_host:
        subprocess.call(cmd_prep_namenode_dir, shell=True)
        subprocess.call(cmd_prep_datanode_dir, shell=True)
        subprocess.call(cmd_namenode_format, shell=True)
        subprocess.Popen(cmd_namenode_start, shell=True)
        subprocess.Popen(cmd_datanode_start, shell=True)
        subprocess.Popen(cmd_resourcemanager_start, shell=True)
        subprocess.Popen(cmd_nodemanager_start, shell=True)
        # TODO: wait for daemons to stabilize on primary + worker nodes
    else:
        subprocess.call(cmd_prep_datanode_dir, shell=True)
        subprocess.Popen(cmd_datanode_start, shell=True)
        subprocess.Popen(cmd_nodemanager_start, shell=True)


# Only start primary node for spark standalone mode, detials in https://spark.apache.org/docs/latest/spark-standalone.html
# This is only used for starting history server, since running histroy server does not require distributing workloads to workers.
def start_primary() -> None:
    cmd_start_primary = "sbin/start-master.sh"
    subprocess.Popen(cmd_start_primary, shell=True)
