default_resource_config = {"current_host": "algo-1", "hosts": ["algo-1"]}
default_processing_job_config = {}
