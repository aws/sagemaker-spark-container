"""Manages the lifecycle of a running Spark job."""
import json
import logging
import os
import socket
import subprocess
import sys
import time
import traceback
from os import path
from typing import Any, Dict, Mapping, Sequence

from smspark.bootstrapper import Bootstrapper
from smspark.defaults import (default_processing_job_config,
                              default_resource_config)
from smspark.spark_event_logs_publisher import SparkEventLogPublisher
from smspark.spark_executor_logs_watcher import SparkExecutorLogsWatcher
from smspark.status import (Status, StatusApp, StatusClient, StatusMessage,
                            StatusServer)
from smspark.waiter import Waiter
from tenacity import retry, stop_after_delay


class ProcessingJobManager(object):
    """Manages the lifecycle of a Spark job."""

    def __init__(
        self, resource_config: Dict[str, Any] = None, processing_job_config: Dict[str, Any] = None,  # type: ignore
    ) -> None:
        """Initialize a ProcessingJobManager, loading configs if not provided."""

        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("smspark-submit")

        try:
            resource_config_path = "/opt/ml/config/resourceconfig.json"
            with open(resource_config_path, "r") as f:
                self._resource_config = json.load(f)
        except Exception:
            self.logger.warning(
                "Could not read resource config file at {}. Using default resourceconfig.".format(resource_config_path)
            )
            self._resource_config = default_resource_config

        self.logger.info(self._resource_config)

        try:
            processing_job_config_path = "/opt/ml/config/processingjobconfig.json"
            with open(processing_job_config_path, "r") as f:
                self._processing_job_config = json.load(f)
        except Exception:
            self.logger.warning(
                "Could not read resource config file at {}. Using default resourceconfig.".format(resource_config_path)
            )
            self._processing_job_config = default_processing_job_config

        self.logger.info(self._processing_job_config)
        self.bootstrapper = Bootstrapper(self._resource_config)
        self.waiter = Waiter()
        self.status_app = StatusApp()
        self.status_client = StatusClient()

    @property
    def hostname(self) -> str:
        return self._resource_config["current_host"]

    @property
    def hosts(self) -> Sequence[str]:
        return self._resource_config["hosts"]

    @property
    def _is_primary_host(self) -> bool:
        current_host = self.hostname
        return current_host == self._cluster_primary_host

    @property
    def _cluster_primary_host(self) -> str:
        return sorted(self._resource_config["hosts"])[0]

    def _wait_for_hostname_resolution(self) -> None:
        for host in self._resource_config["hosts"]:
            self._dns_lookup(host)

    @retry(stop=stop_after_delay(60))
    def _dns_lookup(self, host: str) -> None:
        socket.gethostbyname(host)

    def run(self,
            spark_submit_cmd: str,
            spark_event_logs_s3_uri: str,
            local_spark_event_logs_dir: str) -> None:
        """Run a Spark job.

        First, wait for workers to come up and bootstraps the cluster.
        Then runs spark-submit, waits until the job succeeds or fails.
        Worker nodes are shut down gracefully.

        Args:
          spark_submit_cmd (str): Command submitted to run spark-submit
        """
        self.logger.info("waiting for hosts")
        self._wait_for_hostname_resolution()
        self.logger.info("starting status server")
        self._start_status_server()
        self.logger.info("bootstrapping cluster")
        self._bootstrap_yarn()
        self.logger.info("starting executor logs watcher")
        self._start_executor_logs_watcher()

        if self._is_primary_host:

            def all_hosts_have_bootstrapped() -> bool:
                host_statuses: Mapping[str, StatusMessage] = self.status_client.get_status(self.hosts)
                has_bootstrapped = [message.status == Status.WAITING for message in host_statuses.values()]
                return all(has_bootstrapped)

            self.waiter.wait_for(predicate_fn=all_hosts_have_bootstrapped, timeout=180.0, period=5.0)
            self.logger.info(f"running {spark_submit_cmd}")
            self._run_spark_submit(spark_submit_cmd, spark_event_logs_s3_uri, local_spark_event_logs_dir)
            self.logger.info("spark submit finished with exit code {}.".format(0))
            sys.exit(0)
        else:
            # workers wait until the primary is up, then wait until it's down.
            def primary_is_up() -> bool:
                try:
                    self.status_client.get_status([self._cluster_primary_host])
                    return True
                except Exception:
                    return False

            def primary_is_down() -> bool:
                return not primary_is_up()

            self.waiter.wait_for(primary_is_up, timeout=60.0, period=1.0)
            self.waiter.wait_for(primary_is_down, timeout=float("inf"), period=5.0)

    def _run_spark_submit(self,
                          spark_submit_cmd: str,
                          spark_event_logs_s3_uri: str,
                          local_spark_event_logs_dir: str) -> None:
        spark_log_publisher = SparkEventLogPublisher(spark_event_logs_s3_uri, local_spark_event_logs_dir)
        spark_log_publisher.start()

        # SparkEventLogPublisher writes event log config to spark-defaults.conf, give it 1 seconds.
        time.sleep(1)
        try:
            subprocess.run(spark_submit_cmd, check=True, shell=True)
        except Exception as e:
            self.logger.info("Exception during processing: " + str(e) + "\n" + traceback.format_exc())
            self._write_output_message("Exception during processing: " + str(e))
            sys.exit(255)
        finally:
            spark_log_publisher.down()

    def _write_output_message(self, message: str) -> None:
        if not path.exists("/opt/ml/output"):
            os.makedirs("/opt/ml/output")

        with open("/opt/ml/output/message", "w") as output_message_file:
            output_message_file.write(message)

    def _bootstrap_yarn(self) -> None:
        self.status_app.status = Status.BOOTSTRAPPING
        self.bootstrapper.bootstrap_smspark_submit()
        self.status_app.status = Status.WAITING

    def _start_executor_logs_watcher(self, log_dir="/var/log/yarn"):
        # TODO: check Yarn configs for yarn.log.dir/YARN_LOG_DIR, in case of overrides
        spark_executor_logs_watcher = SparkExecutorLogsWatcher(log_dir)
        spark_executor_logs_watcher.daemon = True
        spark_executor_logs_watcher.start()

    def _start_status_server(self):
        server = StatusServer(self.status_app, self.hostname)
        server.daemon = True
        server.start()
